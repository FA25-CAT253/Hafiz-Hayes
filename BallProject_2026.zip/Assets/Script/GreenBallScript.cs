using UnityEngine;
using UnityEngine.Rendering;

public class GreenBallScript : MonoBehaviour
{
    public float moveSpeed;
    private float jumpforce;
    public GameObject greenball;
    public Rigidbody2D my_rb;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {//Begin.Start.Function
        Debug.Log("oh, Hello there. This is the GreenBallScript's Start ;p");
    }//End.Start.Function

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow))

        Debug.Log("Right arrow key pressed");

        my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);


        if (Input.GetKey(KeyCode.LeftArrow))

            Debug.Log("Left arrow key pressed"); 

        my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);


        if (Input.GetKeyUp(KeyCode.UpArrow)) if (Input.GetKey(KeyCode.Space))
            Debug.Log("Up arrow key pressed");

        my_rb.AddForce(Vector2.up * .2f, ForceMode2D.Impulse);

    }
}
